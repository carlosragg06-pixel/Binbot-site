BINBOT WEBSITE — QUICK SETUP

Files:
- index.html
- assets/robot-closeup.jpeg
- assets/robot-full.jpeg

UPLOAD TO GITHUB:
1. Open https://github.com/carlosragg06-pixel/Binbot-site
2. Tap Add file > Upload files.
3. Upload index.html and the assets folder (keep the folder structure).
   If uploading folders from a phone is difficult, unzip this package on a computer,
   then drag index.html and the assets folder into GitHub's upload area.
4. Commit changes to the main branch.
5. Open Settings > Pages.
6. Under Build and deployment, choose Deploy from a branch.
7. Choose branch main and folder /(root), then Save.
8. Wait a few minutes. The site URL should be:
   https://carlosragg06-pixel.github.io/Binbot-site/

The site is static and uses no paid services or API keys.
